-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tierlist
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `skill`
--

DROP TABLE IF EXISTS `skill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `skill` (
  `id` bigint NOT NULL,
  `active` bit(1) NOT NULL,
  `ammo` int DEFAULT NULL,
  `character_id` bigint NOT NULL,
  `cooldown` int DEFAULT NULL,
  `description` text,
  `name` varchar(255) NOT NULL,
  `reload_time` int DEFAULT NULL,
  `type` enum('BURST','NORMAL','SKILL1','SKILL2') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKl2lsc4q8edqk20f7u7xbedd9k` (`character_id`),
  CONSTRAINT `FKl2lsc4q8edqk20f7u7xbedd9k` FOREIGN KEY (`character_id`) REFERENCES `characters` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skill`
--

LOCK TABLES `skill` WRITE;
/*!40000 ALTER TABLE `skill` DISABLE KEYS */;
INSERT INTO `skill` VALUES (52,_binary '',90,1,NULL,'■ Affects target enemy. Deals 5.59% ATK as damage. Deals 200% damage when attacking core.','Normal Attack',1,'NORMAL'),(102,_binary '\0',10,1,NULL,'■ Activates when using Burst Skill. Affects self.\n\nEffect changes according to the number of activation time(s). Previous effects trigger repeatedly:\n\nOnce: Max HP ▲ 10.03% continuously.\n\nTwice: Max HP ▲ 20.06% continuously.\n\nThree times: Max HP ▲ 57.76% continuously','Survive',100,'NORMAL'),(152,_binary '\0',60,2,0,'■ Affects Target(s).\n\nDeals 14.71% of ATK as damage.\n\nDeals 200% damage when attacking core.\n','Normal Attack',1,'NORMAL'),(153,_binary '\0',0,2,0,'■ Activates when entering battle. Affects all allies.\n\nPerfect Maid: Gain debuff immunity to 1 debuff(s) and stacks up to 1 times(s) continuously.\n\n■ Activates when own HP falls below 90%. Affects all allies.\n\nATK ▲ 5.19% of caster\'s ATK for 5 sec.','Cleaning Time',0,'SKILL1');
/*!40000 ALTER TABLE `skill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-16 17:41:53
