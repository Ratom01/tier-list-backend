-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tierlist
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ranking`
--

DROP TABLE IF EXISTS `ranking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ranking` (
  `character_id` bigint NOT NULL,
  `boss` enum('A','B','C','D','E','F','S','SS','SSS') DEFAULT NULL,
  `pvp` enum('A','B','C','D','E','F','S','SS','SSS') DEFAULT NULL,
  `rank_img_url` varchar(255) DEFAULT NULL,
  `story` enum('A','B','C','D','E','F','S','SS','SSS') DEFAULT NULL,
  PRIMARY KEY (`character_id`),
  CONSTRAINT `FKa7bnyu41ts1ghne9wpscj9gap` FOREIGN KEY (`character_id`) REFERENCES `characters` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ranking`
--

LOCK TABLES `ranking` WRITE;
/*!40000 ALTER TABLE `ranking` DISABLE KEYS */;
INSERT INTO `ranking` VALUES (2,'D','C','https://www.prydwen.gg/static/f1b35b8aca00fbf7e372d1b0c9559010/60b4d/Ade_Icon_160x160.webp','C'),(52,'SSS','B','https://www.prydwen.gg/static/e6dae15e91a67b559d3885af105c0ee2/60b4d/crown_icon.webp','SSS'),(102,'D','D','https://www.prydwen.gg/static/2c1fb4771bf36105a46781520f9ca6a3/60b4d/186_sm.webp','D'),(103,'A','B','https://www.prydwen.gg/static/773d650379b7b72fbf14706cfb3f60a8/60b4d/201_s.webp','A'),(104,'D','C','https://www.prydwen.gg/static/d3a75a27659f2aa4baf6ac90679b6e6b/60b4d/Diesel_Icon_160x160.webp','D'),(152,'A','A','https://www.prydwen.gg/static/019ebfee7d1ed74683d74c04b6cb2939/60b4d/ein_icon.webp','SS'),(153,'D','B','https://www.prydwen.gg/static/2f2302e5b3800447942472cdfcc320b6/60b4d/flora_Icon.webp','C'),(154,'SSS','S','https://www.prydwen.gg/static/ac5dbca4abe85de11ee24d81631e2283/60b4d/siren_sm.webp','SSS'),(155,'B','E','https://www.prydwen.gg/static/1a16edd5f7df4332e0fad8bfd2be70dd/60b4d/Rem_Icon_160x160.webp','B'),(156,'F','F','https://www.prydwen.gg/static/5eeb1022cd37529d4438a5c375d08859/60b4d/Product_08_Icon_160x160.webp','F'),(157,'F','F','https://www.prydwen.gg/static/89c049e8cfb307aad0eee73cf4dabecb/60b4d/Soldier_OW_Icon_160x160.webp','F'),(158,'F','F','https://www.prydwen.gg/static/53a4a7e699c474238bd935a5edcfcfb3/60b4d/Idol_Sun_Icon_160x160.webp','F');
/*!40000 ALTER TABLE `ranking` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-08 23:53:48
