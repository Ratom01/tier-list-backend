-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: tierlist
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `characters` (
  `id` bigint NOT NULL,
  `attack_type` enum('ATTACKER','DEFENDER','SUPPORTER') DEFAULT NULL,
  `burst_type` enum('BURST1','BURST2','BURST3') DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `element_type` enum('ELECTRIC','FIRE','IRON','WATER','WIND') DEFAULT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `manufacturer_type` enum('ABNORMAL','ELYSION','MISSILIS','PILGIRM','TETRA') DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `rarity_type` enum('R','S','SR') DEFAULT NULL,
  `rifle_type` enum('ASSAULTRIFLE','MINIGUN','ROCKETLAUNCHER','SHOTGUN','SMG','SNIPERRIFLE') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (2,'SUPPORTER','BURST2','This is Ade.','WIND','https://www.prydwen.gg/static/33a56d2e73d1ca771c68cff8c301851c/2547a/Ade_Card_262x358.webp','TETRA','Ade','SR','ASSAULTRIFLE'),(52,'DEFENDER','BURST2','...','IRON','https://www.prydwen.gg/static/2d2e8f8c753aa6939bc36947d34de9f4/2547a/crown_card.webp','PILGIRM','Crown','SR','MINIGUN'),(102,'SUPPORTER','BURST1','...','ELECTRIC','https://www.prydwen.gg/static/0a766ea4882aef76b2fbd670154be9af/2547a/186_card.webp','ABNORMAL','Claire Redfield','S','ROCKETLAUNCHER'),(103,'ATTACKER','BURST3','...','IRON','https://www.prydwen.gg/static/f333c084edaed30421c6f80c55bdab97/2547a/201_c.webp','ABNORMAL','Chisato Nishikigi','SR','SMG'),(104,'DEFENDER','BURST2','...','WIND','https://www.prydwen.gg/static/78efab51a0c6361e0bbf93671d2a3192/2547a/Diesel_Card_262x358.webp','ELYSION','Diesel','SR','MINIGUN'),(152,'ATTACKER','BURST3','...','ELECTRIC','https://www.prydwen.gg/static/997df4e3f7cc1f4aed6439c86574bcb1/2547a/ein_card.webp','MISSILIS','Ein','SR','SNIPERRIFLE'),(153,'SUPPORTER','BURST2','...','ELECTRIC','https://www.prydwen.gg/static/004ad7fabe00771f99c877acf79fd547/2547a/flora_card.webp','MISSILIS','Flora','SR','MINIGUN'),(154,'SUPPORTER','BURST1','...','WIND','https://www.prydwen.gg/static/5478dd76a112add81a660fca825cec1a/2547a/siren_card.webp','PILGIRM','Little Mermaid (Siren)','SR','SMG'),(155,'SUPPORTER','BURST2','...','WATER','https://www.prydwen.gg/static/684266877379fa323bc28fd3c3874327/2547a/Rem_Card_262x358.webp','ABNORMAL','Rem','SR','MINIGUN'),(156,'SUPPORTER','BURST1','...','ELECTRIC','https://www.prydwen.gg/static/ef622bcd7eeadd7936bc7515c226d45e/2547a/Product_08_Card_262x358.webp','MISSILIS','Product 08','R','SNIPERRIFLE'),(157,'SUPPORTER','BURST1','...','FIRE','https://www.prydwen.gg/static/93e6c546ef0cd00572aec0f589a310ca/2547a/Soldier_OW_Card_262x358.webp','ELYSION','Soldier OW','R','SMG'),(158,'SUPPORTER','BURST3','...','IRON','https://www.prydwen.gg/static/5188a7bbba0d709a78f88de852b0e088/2547a/Idol_Sun_Card_262x358.webp','TETRA','iDoll Sun','R','ASSAULTRIFLE');
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-08 23:53:48
